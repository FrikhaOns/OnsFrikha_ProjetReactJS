const Footer = () => {
    return ( 
        <footer>
        All copyrights &copy; return to ONS
        </footer>
     );
}
 
export default Footer;