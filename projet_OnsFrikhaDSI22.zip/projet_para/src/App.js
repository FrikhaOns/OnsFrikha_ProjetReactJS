import './App.css';
import Avene from './Components/Skin/Avène';
import Cerave from './Components/Skin/Cerave';
import LaRochePosay from './Components/Skin/LaRochePosay';
import Givenchy from './Components/Parfums/Givenchy';
import Lancome from './Components/Parfums/Lancome';
import Clients from './Components/ManageClient/TabClient';
import Navbar from './Header/Navbar';
import EditArticle from './Components/ManageArticles/EditArticle';
import Home from './Home/Home';
import EditClient from './Components/ManageClient/EditClient';
import AddArticle from './Components/ManageArticles/AddArticle';
import AddClient from './Components/ManageClient/AddClient';
import Cart from "./Components/clientSide/Cart";
import PdfCart from "./Components/clientSide/PdfCart";
import { CartProvider } from "use-shopping-cart";
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import User from './Components/user/User';
import Admin from './Components/admin/Admin';
import LoginClient from './Components/authentificationClient/loginClient';
import Signup from "./Components/authentificationClient/Signup";
import Footer from './Footer';

function App() {
  return (
    <div className="App">
      <CartProvider>
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/LaRochePosay" element={<LaRochePosay />} />
            <Route path="/Cerave" element={<Cerave />} />
            <Route path="/Avene" element={<Avene />} />
            <Route path="/Givenchy" element={<Givenchy />} />
            <Route path="/Lancome" element={<Lancome />} />
            <Route path="/AjoutArticle" element={<AddArticle />} />
            <Route path="/AjoutClient" element={<AddClient />} />
            <Route path="/Clients" element={<Clients />} />
            <Route path='/editArticle/:id' element={<EditArticle />} />
            <Route path='/editClient/:id' element={<EditClient />} />
            <Route path='/user' element={<User />} />
            <Route path='/admin' element={<Admin />} />
            <Route path='*' element={<h1>Not Found</h1>} />
            <Route path='/cart' element={<Cart />} />
            <Route path='/pdfCart' element={<PdfCart />} />
        <Route path="/loginclient" exact element={<LoginClient/>} />
            <Route path="/signup" exact element={<Signup/>} />
          </Routes>
          <Footer/>
        </Router>
      </CartProvider>
    </div>
  );
}

export default App;
