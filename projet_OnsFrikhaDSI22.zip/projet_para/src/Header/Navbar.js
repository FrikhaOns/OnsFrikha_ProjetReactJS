import React, { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Dropdown } from 'react-bootstrap';

import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import "../DarkMode/DarkMode.css";
import DarkMode from '../DarkMode/DarkMode';
import { Badge } from '@mui/material';
import { useShoppingCart } from 'use-shopping-cart';
function Navbar() {
  const [showSkinDropdown, setShowSkinDropdown] = useState(false);
  const [showParfumDropdown, setShowParfumDropdown] = useState(false);
  const [role, setRole] = useState("")
  const { cartCount } = useShoppingCart()
  const handleSkinMouseEnter = () => {
    setShowSkinDropdown(true);
  };

  const handleSkinMouseLeave = () => {
    setShowSkinDropdown(false);
  };

  const handleParfumMouseEnter = () => {
    setShowParfumDropdown(true);
  };

  const handleParfumMouseLeave = () => {
    setShowParfumDropdown(false);
  };

  useEffect(() => {
    if (localStorage.getItem("role")) {
      setRole(localStorage.getItem("role"))
    }
  }, [])

  return (
    <nav className="navbar  navbar-expand-lg bg-light">
      <div className="container-fluid">
      <span className="navbar-brand" 
      style={{ color: 'magenta', fontWeight: 'bold', fontFamily: 'cursive' }}>
  CosmaShop
</span>


        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <NavLink className="nav-link " aria-current="page" to="/">
                Home
              </NavLink>
            </li>

            <Dropdown
              as="li"
              className="skin-dropdown"
              onMouseEnter={handleSkinMouseEnter}
              onMouseLeave={handleSkinMouseLeave}
            >
              <Dropdown.Toggle as="a" className="nav-link" id="dropdown-skin">
                Skin
              </Dropdown.Toggle>
              <Dropdown.Menu style={{ display: showSkinDropdown ? 'block' : 'none' }}>
                <NavLink to="/LaRochePosay" className="dropdown-item">
                  La Roche Posay
                </NavLink>
                <NavLink to="/Avene" className="dropdown-item">
                  Avène
                </NavLink>
                <NavLink to="/Cerave" className="dropdown-item">
                  Cerave
                </NavLink>
              </Dropdown.Menu>
            </Dropdown>
            <Dropdown
              as="li"
              className="parfum-dropdown"
              onMouseEnter={handleParfumMouseEnter}
              onMouseLeave={handleParfumMouseLeave}
            >
              <Dropdown.Toggle as="a" className="nav-link" id="dropdown-parfum">
                Parfum
              </Dropdown.Toggle>
              <Dropdown.Menu style={{ display: showParfumDropdown ? 'block' : 'none' }}>
                <NavLink to="/Givenchy" className="dropdown-item">
                  Givenchy
                </NavLink>
                <NavLink to="/Lancome" className="dropdown-item">
                  Lancome
                </NavLink>
              </Dropdown.Menu>
            </Dropdown>
            {role === "admin" && <>

              <NavLink className="nav-link " aria-current="page" to="/AjoutArticle">
                Ajout Produit
              </NavLink>
              <NavLink className="nav-link " aria-current="page" to="/AjoutClient">
                Ajout Client
              </NavLink>
              <NavLink className="nav-link " aria-current="page" to="/Clients">
                Clients
              </NavLink></>}
            <DarkMode />
          </ul>
          <form className="d-flex " role="search">
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />
            <button className="btn btn-outline-info" type="submit">
              Search
            </button>

          </form>
          {role !== "admin" && <Badge badgeContent={cartCount} color="primary" >
            <Link to="/cart"> <AddShoppingCartIcon /></Link>
          </Badge>}


        </div>
      </div>
    </nav>
  );
}

export default Navbar;
