import { Link } from "react-router-dom";
import Slide from "../Components/Slide";

function Home() {
    return (<div>
        <Slide />
        <h1 className="title">SHOP NOW</h1>
        <div className="homeImages">
            <Link to="/Givenchy"> <img src="./imageshome/parfum.jpg" alt="perfim" width={500} height={400}/></Link>
           <Link to="/LaRochePosay">
            <img src="./imageshome/skin.jpg" alt="skin" width={500} height={400}/>
           </Link>
        </div>
    </div> );
}

export default Home;
