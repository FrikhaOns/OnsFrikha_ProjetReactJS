import React from "react";
import { Navigate } from "react-router-dom";


const User = () => {
    localStorage.setItem("role", "user")

    return <>
        <Navigate to={"/"} />
    </>
}

export default User