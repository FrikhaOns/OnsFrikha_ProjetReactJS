import { Swiper, SwiperSlide } from 'swiper/react'; // Importez Swiper et SwiperSlide
import 'swiper/css';
import 'swiper/css/navigation';

// Importez les modules que vous souhaitez utiliser
import { Autoplay, EffectFade, Navigation } from 'swiper/modules';



export default function Slide() {
  return (
    <>
      <div className='container2'>
        <Swiper navigation={true} modules={[EffectFade, Navigation, Autoplay]} autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }} className="mySwiper">
          <SwiperSlide>
            <div className='div-img'>
              <img src='https://www.pointm.tn/modules/homeslider/images/b37b938a61e8e3c8a64d3cdb7448908a4d6212ca_banniere.png' alt='asad' />
            </div>
          </SwiperSlide>
          
          <SwiperSlide>
            <div className='div-img'>
              <img src='https://www.pointm.tn/modules/themeconfigurator/img/da2848688ba35ddf47fb9596b81e8a9804ad751e_pointm-make-up.png' alt='asad' />
            </div>
          </SwiperSlide>

          <SwiperSlide>
            <div className='div-img'>
              <img src='https://www.pointm.tn/modules/homeslider/images/cd445cc49cf40be4009c811644f6f22ab9c23f0c_POINT%20M%20-%20Nereides%203.png' alt='asad' />
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </>
  ); 
}