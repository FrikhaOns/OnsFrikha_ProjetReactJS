import React from 'react';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import { Link } from "react-router-dom";
import { useShoppingCart } from 'use-shopping-cart';
function ElementsArticle(props) {
  const { addItem } = useShoppingCart();
  const addToCart = (product) => {
      
    const target = { 
    id : product.id+product.marque_Spec,
    title : product.designation,
    image : product.imageartpetitf,
    price : product.prixVente,
    qtestock : product.qtestock,
    quantity : 1
    };
    addItem(target);
    console.log('Item added to cart:', target);
   
  };
  return (
    <>
      <div className="card-container">
        {props.articles &&
          props.articles.map((article) => (
            <div key={article.id} >
              <Card style={{ width: '18rem' }}>
                <Card.Img
                  variant="top"
                  src={article.imageartpetitf}
                  alt={article.designation}
                  onMouseEnter={(e) => {
                    e.currentTarget.src = article.imageartpetitfHover;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.src = article.imageartpetitf;
                  }}
                />
                <Card.Body>
                  <Card.Title className='form-titre'>{article.designation}</Card.Title>
                  <center><Card.Text className='form-titre'>{article.marque}</Card.Text></center>
                </Card.Body>
                <ListGroup className='form-titre' >
                  <center><ListGroup.Item>{article.prixVente} TND</ListGroup.Item></center>
                </ListGroup>
                <Card.Body>
                  {localStorage.getItem("role") === "admin" ? <><Link exact to={`/editArticle/${article.id}?data=${article.marque_Spec}`} className="btn btn-success">Modifier</Link>
                    <button onClick={() => { props.deleteProd(article.id) }} className="btn btn-info">Supprimer</button></> :
                     <center><button
                     onClick={()=>addToCart(article)}
                     disabled={article.qtestock <= 1}
                     className="btn btn-info"
                     >
                    Add to Cart
                  </button></center>
                  }

                </Card.Body>
              </Card>
            </div>
          ))}</div>
    </>
  );
}

export default ElementsArticle;
