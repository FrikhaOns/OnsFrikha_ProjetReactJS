import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddArticle() {
    const navigate = useNavigate();
    const [reference, setReference] = useState("");
    const [designation, setDesignation] = useState("");
    const [prixAchat, setPrixAchat] = useState("");
    const [prixVente, setPrixVente] = useState("");
    const [qtestock, setQtestock] = useState("");
    const [imageartpetitf, setImageartpetitf] = useState(null); 
    const [imageartpetitfHover, setImageartpetitfHover] = useState(null); 
    const [categorie, setCategorie] = useState("");
    const [marqueSpecific, setMarqueSpecific] = useState("");

    const handleImageartpetitfChange = (e) => {
        const file = e.target.files[0]; 
        setImageartpetitf(file.name);
    };

    const handleImageartpetitfHoverChange = (e) => {
        const file = e.target.files[0];
        console.log(file.name);
        setImageartpetitfHover(file.name);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const newProduct = {
            reference,
            designation,
            marque: `${categorie} - ${marqueSpecific}`, 
            prixAchat,
            prixVente,
            qtestock,
            imageartpetitf:`images/${marqueSpecific}/${imageartpetitf}`,
            imageartpetitfHover:`images/${marqueSpecific}/${imageartpetitfHover}`,
        };

        axios.post(`http://localhost:3001/${marqueSpecific}`, newProduct)
       
            .then(res => {
                console.log(res);
                navigate(`/${marqueSpecific}`);
            })
            .catch(error => {
                console.log(error);
                alert("Erreur ! Insertion non effectuée");
            });
    }

    return (
        <div className="container">
            <h2 className='title'>Ajout d'un produit</h2>
            <form onSubmit={handleSubmit}>
    <div className="container mt-4">
        <div className="row">
            <div className="col-md-6">
                <label htmlFor="reference" className="form-label">Référence</label>
                <input
                    id="reference"
                    className="form-control"
                    placeholder="Référence"
                    type="text"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                />
            </div>
            <div className="col-md-6">
                <label htmlFor="categorie" className="form-label">Catégorie</label>
                <select
                    id="categorie"
                    className="form-select"
                    value={categorie}
                    onChange={(e) => setCategorie(e.target.value)}
                >
                    <option value="">Sélectionnez une catégorie</option>
                    <option value="parfum">Parfum</option>
                    <option value="soin">Soin</option>
                </select>
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-6">
                <label htmlFor="marqueSpecific" className="form-label">Marque</label>
                <select
                    id="marqueSpecific"
                    className="form-select"
                    value={marqueSpecific}
                    onChange={(e) => setMarqueSpecific(e.target.value)}
                    disabled={!categorie}
                >
                    <option value="">Sélectionnez une marque</option>
                    {categorie === "parfum" ? (
                        <>
                            <option value="Givenchy">Givenchy</option>
                            <option value="Lancome">Lancome</option>
                        </>
                    ) : categorie === "soin" ? (
                        <>
                            <option value="LaRochePosay">La Roche Posay</option>
                            <option value="Avene">Avène</option>
                            <option value="Cerave">Cerave</option>
                        </>
                    ) : null}
                </select>
            </div>
            <div className="col-md-6">
                <label htmlFor="designation" className="form-label">Désignation</label>
                <input
                    id="designation"
                    className="form-control"
                    placeholder="Désignation"
                    type="text"
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                />
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-6">
                <label htmlFor="prixAchat" className="form-label">Prix Achat</label>
                <input
                    id="prixAchat"
                    className="form-control"
                    placeholder="Prix Achat"
                    type="number"
                    value={prixAchat}
                    onChange={(e) => setPrixAchat(e.target.value)}
                />
            </div>
            <div className="col-md-6">
                <label htmlFor="prixVente" className="form-label">Prix Vente</label>
                <input
                    id="prixVente"
                    className="form-control"
                    placeholder="Prix Vente"
                    type="number"
                    value={prixVente}
                    onChange={(e) => setPrixVente(e.target.value)}
                />
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-6">
                <label htmlFor="qtestock" className="form-label">Quantité</label>
                <input
                    id="qtestock"
                    className="form-control"
                    placeholder="Quantité"
                    type="number"
                    value={qtestock}
                    onChange={(e) => setQtestock(e.target.value)}
                />
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-6">
                <label htmlFor="imageartpetitf" className="form-label">Image Petit Format</label>
                <input
                    id="imageartpetitf"
                    type="file"
                    onChange={handleImageartpetitfChange}
                />
                {imageartpetitf && (
                    <img src={`images/${marqueSpecific}/${imageartpetitf}`} alt="" className="mt-2" width="70" />
                )}
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-6">
                <label htmlFor="imageartpetitfHover" className="form-label">Image Petit Format Hover</label>
                <input
                    id="imageartpetitfHover"
                    type="file"
                    onChange={handleImageartpetitfHoverChange}
                />
                {imageartpetitfHover && (
                    <img src={`images/${marqueSpecific}/${imageartpetitfHover}`} alt="" className="mt-2" width="70" />
                )}
            </div>
        </div>

        <div className="row mt-3">
            <div className="col-md-12">
                <center><button className="btn btn-info">Valider</button></center>
            </div>
        </div>
    </div>
</form>

        </div>
    );
}

export default AddArticle;