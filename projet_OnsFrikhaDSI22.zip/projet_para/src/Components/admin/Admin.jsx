import React from "react";
import { Navigate } from "react-router-dom";


const Admin = () => {
    localStorage.setItem("role", "admin")
    return <>
        <Navigate to={"/"} />
    </>
}

export default Admin