import axios from 'axios';
import {useEffect,useState} from 'react';
import ElementsArticle from '../ManageArticles/ElementsArticle';
function List_Cerave() {

    const[Cerave,setCerave]=useState([]);
       useEffect(() => {
        axios.get("http://localhost:3001/Cerave")
        .then((response)=>setCerave(response.data));
       }, []);
       const deleteProd = async (id) => {
         if (!window.confirm("Are you sure you want to delete")) {
           return;
         }
     
         axios.delete('http://localhost:3001/Cerave/' + id)
           .then(() => {
             console.log('successfully deleted!')
             setCerave(prevArticles => prevArticles.filter((Cerave) => Cerave.id !== id));
           }).catch((error) => {
             console.log(error)
           })
     
       }


    return ( 
        <>
        <h2 className='title'>Liste des produits Cerave </h2>
        <ElementsArticle articles={Cerave} deleteProd={deleteProd} />
        </>
     );
}

export default List_Cerave;