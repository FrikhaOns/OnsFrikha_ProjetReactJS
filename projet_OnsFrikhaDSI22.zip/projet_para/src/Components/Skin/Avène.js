import axios from 'axios';
import {useEffect,useState} from 'react';
import ElementsArticle from '../ManageArticles/ElementsArticle';
function List_Avène() {

    const[Avene,setAvène]=useState([]);
       useEffect(() => {
        axios.get("http://localhost:3001/Avene")
        .then((response)=>setAvène(response.data));
       }, []);
       const deleteProd = async (id) => {
         if (!window.confirm("Are you sure you want to delete")) {
           return;
         }
     
         axios.delete('http://localhost:3001/Avene/' + id)
           .then(() => {
             console.log('successfully deleted!')
             setAvène(prevArticles => prevArticles.filter((Avene) => Avene.id !== id));
           }).catch((error) => {
             console.log(error)
           })
     
       }
   

    return ( 
        <>
        <h2 className='title'>Liste des produits Avène </h2>
        <ElementsArticle articles={Avene} deleteProd={deleteProd}/>
        </>
     );
}

export default List_Avène;