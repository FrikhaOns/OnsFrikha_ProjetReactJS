import axios from 'axios';
import {useEffect,useState} from 'react';
import ElementsArticle from '../ManageArticles/ElementsArticle';
function List_La_Roche_Posay() {
    const[LaRochePosay,setLa_Roche_Posay]=useState([]);
    
    useEffect(() => {
        axios.get("http://localhost:3001/LaRochePosay")
        .then((response)=>setLa_Roche_Posay(response.data));
       }, []);
         const deleteProd = async (id) => {
            if (!window.confirm("Are you sure you want to delete")) {
              return;
            }
        
            axios.delete('http://localhost:3001/LaRochePosay/' + id)
              .then(() => {
                console.log('successfully deleted!')
                setLa_Roche_Posay(prevArticles => prevArticles.filter((LaRochePosay) => LaRochePosay.id !== id));
              }).catch((error) => {
                console.log(error)
              })
        
          }

    return ( 
        <>
        <h2 className='title'>Liste des produits La Roche Posay </h2>
        <ElementsArticle articles={LaRochePosay} deleteProd={deleteProd} />
        </>
     );
}

export default List_La_Roche_Posay;