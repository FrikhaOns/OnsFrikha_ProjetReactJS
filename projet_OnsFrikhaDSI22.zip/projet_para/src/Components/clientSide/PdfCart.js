import React from 'react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { useShoppingCart } from 'use-shopping-cart';

const PdfCart = () => {
  const { cartDetails, totalPrice } = useShoppingCart();

  const generatePDF = (tableRows, columns, isLandscape) => {
    const doc = new jsPDF({
      orientation: isLandscape ? 'landscape' : 'portrait',
    });

    doc.autoTable({
      head: [columns],
      body: tableRows,
      startY: 30,
      headStyles: {
        fillColor: [230, 20, 15],
        fontSize: 12,
        halign: 'center',
      },
      columnStyles: {
        0: { cellWidth: 30, cellHeight: 20, halign: 'center' },
        1: { cellWidth: 'auto', halign: 'center', fontStyle: 'bold' },
        2: { cellWidth: 30, halign: 'center' },
        3: { cellWidth: 30, halign: 'center' },
        4: { cellWidth: 30, halign: 'center' },
      },
      styles: {
        valign: 'middle',
      },
      didParseCell: function (data) {
        if (data.section === 'body') {
          data.row.height = 20;
        }
        if (data.column.index === 0 && data.section === 'body') {
          // Remove the incorrect line below
          // data.cell.raw = ${data.cell.raw};
        }
      },
      didDrawCell: function (data) {
        if (data.column.index === 0 && data.section === 'body') {
          const imageUrl = data.row.raw[0];

          // Convert image URL to base64
          const img = new Image();
          img.src = imageUrl;
          const base64Img = getBase64Image(img);

          doc.addImage(base64Img, 'JPEG', data.cell.x + 2, data.cell.y + 2, 30, 20);
        }
      },
    });

    const date = new Date().toDateString();
    // Corrected the template literals
    doc.text(`Total: ${totalPrice.toFixed(3)} TND`, 14, 10);
    doc.text(`Date: ${date}`, 14, 20);
    // Added quotes around the file name
    doc.save(`report_${date}.pdf`);
  };

  // Function to convert image to base64
  const getBase64Image = (img) => {
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;

    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);

    const dataURL = canvas.toDataURL('image/jpeg');
    return dataURL.replace(/^data:image\/(png|jpg);base64,/, '');
  };

  const columnsPDF = ['image', 'title', 'quantity', 'price', 'STotal'];
  const rowsLine = () => {
    let rows = Object.values(cartDetails).map((item, index) => [
      item.image,
      item.title,
      item.quantity,
      item.price,
      (item.price * item.quantity).toFixed(3),
    ]);
    return rows;
  };

  return (
    <>
      <button
        style={{
          color: 'yellow',
          backgroundColor: 'teal',
          height: 70,
          position: 'fixed',
          top: 150,
          left: 150,
          cursor: 'pointer',
        }}
        onClick={() => generatePDF(rowsLine(), columnsPDF, true)}
      >
        Télécharger PDF
      </button>
    </>
  );
};

export default PdfCart;
