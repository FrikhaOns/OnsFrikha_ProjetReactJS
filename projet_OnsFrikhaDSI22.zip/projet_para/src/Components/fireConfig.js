import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyD5Q9qSl12fcCnx8aE2MgbvLRI5xTSJnlE",
  authDomain: "cosm-e18e4.firebaseapp.com",
  projectId: "cosm-e18e4",
  storageBucket: "cosm-e18e4.appspot.com",
  messagingSenderId: "734004830803",
  appId: "1:734004830803:web:36a2277e91cdee8fbb5ca6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app)
export  {auth} 
export default db;
