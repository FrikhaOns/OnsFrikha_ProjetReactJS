export const lightTheme = {
    backgroundColor: 'white',
    textColor: 'black',
  };
  
  export const darkTheme = {
    backgroundColor: 'black',
    textColor: 'white',
  };
  