import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import Row from 'react-bootstrap/Row';
import { useNavigate } from 'react-router-dom';

function AddClient() {
  const navigate = useNavigate();
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [numtel, setNumTel] = useState("");
  const [email, setEmail] = useState("");
  const [ville, setVille] = useState("");
  const [adresse, setAdresse] = useState("");
  const [image, setImage] = useState("");
  const handleImageChange = (e) => {
    const file = e.target.files[0]; 
    setImage(file.name);
};


  const handleSubmit = async (event) => {
    event.preventDefault();
    const newClient = {
      nom,
      prenom,
      numtel,
      email,
      ville,
      adresse,
      image
  }
  axios.post("http://localhost:3001/clients",newClient)
  .then(res => {  
  console.log(res);
  navigate("/clients")
    })   
  .catch(error=>{
      console.log(error)
      alert("Erreur ! Insertion non effectuée")
      })
 
  };

  return (
    <Form   onSubmit={handleSubmit}>
      <h2 className='title'>Ajout d'un nouveau client</h2>

      <Row className="mb-3">
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom01">
            <Form.Label className="form-label">Nom</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder="Nom"
              value={nom}
              onChange={(e) => setNom(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              Veuillez saisir le nom du client.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom02">
            <Form.Label className="form-label">Prénom</Form.Label>
            <Form.Control
              required
              type="text"
              placeholder="Prénom"
              value={prenom}
              onChange={(e) => setPrenom(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              Veuillez saisir le prénom du client.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>
      <Row className="mb-3">
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom03">
            <Form.Label className="form-label">Numéro de téléphone</Form.Label>
            <Form.Control
              required
              type="number"
              placeholder="Numéro de téléphone"
              value={numtel}
              onChange={(e) => setNumTel(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              Veuillez saisir un numéro de téléphone valide.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom04">
            <Form.Label className="form-label">Email</Form.Label>
            <Form.Control
              required
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              Veuillez saisir une adresse email valide.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>
      <Row className="mb-3">
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom05">
            <Form.Label className="form-label">Ville</Form.Label>
            <Form.Control
              as="select"
              value={ville}
              onChange={(e) => setVille(e.target.value)}
              required
            >
              <option value="">Sélectionnez une ville</option>
              <option value="Ariana">Ariana</option>
  <option value="Béja">Béja</option>
  <option value="Ben Arous">Ben Arous</option>
  <option value="Bizerte">Bizerte</option>
  <option value="Gabes">Gabes</option>
  <option value="Gafsa">Gafsa</option>
  <option value="Jendouba">Jendouba</option>
  <option value="Kairouan">Kairouan</option>
  <option value="Kasserine">Kasserine</option>
  <option value="Kebili">Kebili</option>
  <option value="La Manouba">La Manouba</option>
  <option value="Le Kef">Le Kef</option>
  <option value="Mahdia">Mahdia</option>
  <option value="Médenine">Médenine</option>
  <option value="Monastir">Monastir</option>
  <option value="Nabeul">Nabeul</option>
  <option value="Sfax">Sfax</option>
  <option value="Sidi Bouzid">Sidi Bouzid</option>
  <option value="Siliana">Siliana</option>
  <option value="Sousse">Sousse</option>
  <option value="Tataouine">Tataouine</option>
  <option value="Tozeur">Tozeur</option>
  <option value="Tunis">Tunis</option>
  <option value="Zaghouan">Zaghouan</option> </Form.Control>
            <Form.Control.Feedback type="invalid">
              Veuillez sélectionner une ville.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom06">
            <Form.Label className="form-label">Adresse</Form.Label>
            <Form.Control
              type="text"
              placeholder="Adresse"
              value={adresse}
              onChange={(e) => setAdresse(e.target.value)}
            />
          </Form.Group>
        </Col>
      </Row>
      <Row className="mb-3">
        <Col md="6" className="mb-3">
          <Form.Group controlId="validationCustom07">
            <Form.Label className="form-label">Image</Form.Label>
            <div className="col-sm-5 p-2 g-col-6">
                        <input
                            type="file"
                            onChange={handleImageChange}
                        />
                    </div>
                    <div>{image? <img src={`images/Clients/${image}`} 
                    alt="" width="70" /> : null}</div>
            <Form.Control.Feedback type="invalid" className="form-label">
              Veuillez sélectionner une image.
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
      </Row>
      <div className="col-md-12">
                <center><Button className="btn btn-info" type="submit ">Valider</Button></center>
            </div>
    </Form>
  );
}

export default AddClient;

