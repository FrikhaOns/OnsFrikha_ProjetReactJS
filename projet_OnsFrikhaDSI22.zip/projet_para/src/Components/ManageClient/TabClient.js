import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';
import Image from 'react-bootstrap/Image';

function ListClients() {
  const [clients, setClients] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:3001/Clients");
        setClients(response.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const deleteClient = async (clientId) => {
    if (!window.confirm("Are you sure you want to delete?")) {
      return;
    }

    try {
      await axios.delete(`http://localhost:3001/Clients/${clientId}`);
      const response = await axios.get("http://localhost:3001/Clients");
      setClients(response.data);
    } catch (error) {
      console.error("Error deleting client or re-fetching data after deletion:", error);
    }
  };

  return (
    <>
    <h2 className='title'>Liste des clients</h2>

    <Table striped bordered hover className="text-center">
      <thead>
        <tr>
          <th>Avatar</th>
          <th>ID</th>
          <th>Nom</th>
          <th>Prénom</th>
          <th>Numéro de téléphone</th>
          <th>Email</th>
          <th>Ville</th>
          <th>Adresse</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {clients.map((client) => (
          <tr key={client.id}>
            <td>
              {client.image && (
                <Image src={`images/clients/${client.image}`} alt="Avatar" roundedCircle style={{ width: '50px', height: '50px' }} />
              )}
            </td>
            <td>{client.id}</td>
            <td>{client.nom}</td>
            <td>{client.prenom}</td>
            <td>{client.numtel}</td>
            <td>{client.email}</td>
            <td>{client.ville}</td>
            <td>{client.adresse}</td>
            <td>
              <Link to={`/EditClient/${client.id}`} className="btn btn-outline-primary">Modifier</Link>
              <button onClick={() => deleteClient(client.id)} className="btn btn-outline-danger">Supprimer</button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
    </>
  );
}

export default ListClients;
