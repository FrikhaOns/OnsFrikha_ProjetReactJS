import React from 'react';

function ElementsClient({ id, nom, prenom, numtel, email,ville,adresse,image,editClient, deleteClient }) {
    const handleEdit = () => {
        editClient(id);
    };

    const handleDelete = () => {
        deleteClient(id);
    };
    return (
        <tr>
            <td>{id}</td>
            <td>{nom}</td>
            <td>{prenom}</td>
            <td>{numtel}</td>
            <td>{email}</td>
            <td>{ville}</td>
            <td>{adresse}</td>
            <td>{<img src={`http://localhost:3000/clients/${image}`} 
                    alt="" width="70" /> }</td>
        </tr>
    );
}

export default ElementsClient;
