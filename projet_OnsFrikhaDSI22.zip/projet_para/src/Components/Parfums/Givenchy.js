import axios from 'axios';
import {useEffect,useState} from 'react';
import ElementsArticle from '../ManageArticles/ElementsArticle';
function Givenchy() {
    const[Givenchy,setGivenchy]=useState([]);
    
    useEffect(() => {
        axios.get("http://localhost:3001/Givenchy")
        .then((response)=>setGivenchy(response.data));
       }, []);

       const deleteProd = async (id) => {
        if (!window.confirm("Are you sure you want to delete")) {
          return;
        }
    
        axios.delete('http://localhost:3001/Givenchy/' + id)
          .then(() => {
            console.log('successfully deleted!')
            setGivenchy(prevArticles => prevArticles.filter((Givenchy) => Givenchy.id !== id));
          }).catch((error) => {
            console.log(error)
          })
    
      }

       
    return ( 
        <>
        <h2 className='title'>Liste des parfums Givenchy </h2>
        <ElementsArticle articles={Givenchy} deleteProd={deleteProd} />
        </>
     );
}
export default Givenchy;