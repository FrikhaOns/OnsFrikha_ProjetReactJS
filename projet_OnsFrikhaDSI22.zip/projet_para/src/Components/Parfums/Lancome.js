import axios from 'axios';
import {useEffect,useState} from 'react';
import ElementsArticle from '../ManageArticles/ElementsArticle';
function Lancome() {
    const[Lancome,setLancome]=useState([]);
    
    useEffect(() => {
        axios.get("http://localhost:3001/Lancome")
        .then((response)=>setLancome(response.data));
       }, []);

       const deleteProd = async (id) => {
        if (!window.confirm("Are you sure you want to delete")) {
          return;
        }
    
        axios.delete('http://localhost:3001/Lancome/' + id)
          .then(() => {
            console.log('successfully deleted!')
            setLancome(prevArticles => prevArticles.filter((Lancome) => Lancome.id !== id));
          }).catch((error) => {
            console.log(error)
          })
    
      }
  

       
    return ( 
        <>
        <h2 className='title'>Liste des parfums Lancome </h2>
        <ElementsArticle articles={Lancome} deleteProd={deleteProd}/>
        </>
     );
}
export default Lancome;